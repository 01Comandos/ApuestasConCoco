//
//  FlagKit.h
//  FlagKit
//
//  Created by Simon Blommegard on 25/10/15.
//  Copyright © 2015 Bowtie. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for FlagKit.
FOUNDATION_EXPORT double FlagKitVersionNumber;

//! Project version string for FlagKit.
FOUNDATION_EXPORT const unsigned char FlagKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FlagKit/PublicHeader.h>


